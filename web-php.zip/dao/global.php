<?php
define("IMG_PATH_ADMIN", "../upload/");
define("IMG_PATH_USER", "upload/");
